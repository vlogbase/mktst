<?php return array (
  'admin.auth.login-form' => 'App\\Http\\Livewire\\Admin\\Auth\\LoginForm',
  'customer.login-form' => 'App\\Http\\Livewire\\Customer\\LoginForm',
  'customer.newsletter-main' => 'App\\Http\\Livewire\\Customer\\NewsletterMain',
  'customer.price-filter' => 'App\\Http\\Livewire\\Customer\\PriceFilter',
  'customer.product-card' => 'App\\Http\\Livewire\\Customer\\ProductCard',
  'customer.product-detail-buttons' => 'App\\Http\\Livewire\\Customer\\ProductDetailButtons',
  'customer.product-list' => 'App\\Http\\Livewire\\Customer\\ProductList',
  'customer.product-page' => 'App\\Http\\Livewire\\Customer\\ProductPage',
  'customer.register-form' => 'App\\Http\\Livewire\\Customer\\RegisterForm',
);