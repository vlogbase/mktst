							
							<!--begin::Container-->
							<div id="kt_content_container" class="container-xxl">
								
								<!--begin::Row-->
								<div class="row gy-5 g-xl-8">
									<!--begin::Col-->
									<div class="col-xl-4">
<!--layout-partial:partials/widgets/mixed/_widget-2.html-->

									</div>
									<!--end::Col-->
									<!--begin::Col-->
									<div class="col-xl-4">

<!--layout-partial:partials/widgets/lists/_widget-5.html-->

									</div>
									<!--end::Col-->
									<!--begin::Col-->
									<div class="col-xl-4">

<!--layout-partial:partials/widgets/mixed/_widget-7.html-->


<!--layout-partial:partials/widgets/mixed/_widget-10.html-->

									</div>
									<!--end::Col-->
								</div>
								<!--end::Row-->
								<!--begin::Row-->
								<div class="row gy-5 g-xl-8">
									<!--begin::Col-->
									<div class="col-xl-4">

<!--layout-partial:partials/widgets/lists/_widget-3.html-->

									</div>
									<!--end::Col-->
									<!--begin::Col-->
									<div class="col-xl-8">

<!--layout-partial:partials/widgets/tables/_widget-9.html-->

									</div>
									<!--end::Col-->
								</div>
								<!--end::Row-->
								<!--begin::Row-->
								<div class="row gy-5 g-xl-8">
									<!--begin::Col-->
									<div class="col-xl-4">

<!--layout-partial:partials/widgets/lists/_widget-2.html-->

									</div>
									<!--end::Col-->
									<!--begin::Col-->
									<div class="col-xl-4">

<!--layout-partial:partials/widgets/lists/_widget-6.html-->

									</div>
									<!--end::Col-->
									<!--begin::Col-->
									<div class="col-xl-4">

<!--layout-partial:partials/widgets/lists/_widget-4.html-->

									</div>
									<!--end::Col-->
								</div>
								<!--end::Row-->
								<!--begin::Row-->
								<div class="row g-5 g-xl-8">
									<!--begin::Col-->
									<div class="col-xl-4">

<!--layout-partial:partials/widgets/mixed/_widget-5.html-->

									</div>
									<!--end::Col-->
									<!--begin::Col-->
									<div class="col-xl-8">

<!--layout-partial:partials/widgets/tables/_widget-5.html-->

									</div>
									<!--end::Col-->
								</div>
								<!--end::Row-->

<!--layout-partial:partials/widgets/calendar/_widget-1.html-->

								
							</div>
							<!--end::Container-->
							