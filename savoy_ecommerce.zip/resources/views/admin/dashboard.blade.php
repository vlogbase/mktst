@extends('admin.layouts.templates.panel')
@section('title','Dashboard')
@section('sub-title','sdsad')
@section('content')
    				<!--begin::Row-->
                    <div class="row gy-5 g-xl-8">
                        <!--begin::Col-->
                        <div class="col-xl-12">
                                Dashboard
                        </div>
                        <!--end::Col-->
                    </div>
@endsection
