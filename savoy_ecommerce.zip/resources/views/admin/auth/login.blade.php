@extends('admin.layouts.templates.auth')
@section('title','Admin Login')
@section('sub-title','')
@section('content')
    @livewire('admin.auth.login-form')

@endsection
