
<?php $__env->startSection('body'); ?>
<body id="kt_body" class=" page-loading-enabled page-loading header-fixed header-tablet-and-mobile-fixed toolbar-enabled toolbar-fixed aside-enabled aside-fixed " style="--kt-toolbar-height:55px;--kt-toolbar-height-tablet-and-mobile:55px">

    <!--layout-partial:layout/_loader.html-->
        <?php echo $__env->make('admin.layouts.partials._loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!--layout-partial:layout/master.html-->
        
        <?php echo $__env->make('admin.layouts.partials._master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <!--layout-partial:layout/engage/_main.html-->
    
    
    <!--layout-partial:layout/_scrolltop.html-->
    <?php echo $__env->make('admin.layouts.partials._scrolltop', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
            <!--begin::Modals-->
    
    <!--layout-partial:partials/modals/_upgrade-plan.html-->
    
    
    <!--layout-partial:partials/modals/create-app/_main.html-->
    
    
    <!--layout-partial:partials/modals/_invite-friends.html-->
    
    
    <!--layout-partial:partials/modals/users-search/_main.html-->
    
            <!--end::Modals-->
            <?php echo $__env->make('admin.layouts.partials.javascripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->yieldContent('js'); ?>
        </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SavoyEcommerce\savoy_ecommerce\resources\views/admin/layouts/templates/panel.blade.php ENDPATH**/ ?>