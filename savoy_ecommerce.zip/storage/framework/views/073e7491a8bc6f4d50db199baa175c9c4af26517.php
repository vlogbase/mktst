
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('sub-title','sdsad'); ?>
<?php $__env->startSection('content'); ?>
    				<!--begin::Row-->
                    <div class="row gy-5 g-xl-8">
                        <!--begin::Col-->
                        <div class="col-xl-12">
                                Dashboard
                        </div>
                        <!--end::Col-->
                    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.templates.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SavoyEcommerce\savoy_ecommerce\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>